<?php 
class Form_model extends CI_Model{
	protected $table='tbl';
	function __Construct(){
		parent::__Construct();
	}
	public function insert_data($data){
		/*echo "<prev>";
		print_r($data);
		exit();*/
		$sql=$this->db->insert('tbl',$data);
		if($sql)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function show_data(){
		$res=$this->db->get('tbl');
		return $res->result();
	}
	public function delete_data($id){
		$this->db->where('id',$id);
		$this->db->delete('tbl');
		return true;
	}
	function edit_data($id){
		$this->db->select('*');
		$this->db->from('tbl');
		$this->db->where('id',$id);
		$data=$this->db->get();
		return $data->result();
	}
	function update_data($id,$data){
		/*echo "<prev>";
		print_r($data);
		exit();*/
		$this->db->where('id',$id);
		$sql=$this->db->update('tbl',$data);
		if($sql)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}


?>