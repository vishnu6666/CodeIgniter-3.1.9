<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Template {
	
	public function full_html_view($content){

		$CI =& get_instance();
		$data = array(
						"title" => 'Home Page',
						"content" => $content
		);
	
		$content = $CI->parser->parse('html_template',$data);
	}
}