<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cform extends CI_Controller {

	public function index()
	{
		$CI =& get_instance();
		$data = array(
	    				'title' => "Form"
	    	         );
		$content = $CI->parser->parse('page/form',$data ,true);	
		$this->template->full_html_view($content);
	}

	/*public function validate(){
		$this->form_validation->set_rules('name','Name','required');
		$this->form_validation->set_rules('gender','Gender','required');
		$this->form_validation->set_rules('hobby','hobby','required');
		$this->form_validation->set_rules('education','education','required');
		//$this->form_validation->set_rules('img','image','required');
		//$this->form_validation->set_rules('gallery','gallery','required');
		echo "y";
		if($this->form_validation->run()==true){
			$this->insert();
			echo "yy";

		}
		else
		{
			echo "n";

			$this->load->view('form_view');
		}
	}
	*/
	public function insert(){
		$CI =& get_instance();
		$h=$this->input->post('hobby');
		$img=$_FILES['img']['name'];
		move_uploaded_file($_FILES['img']['tmp_name'], "my-assets/img/$img");
		$gallery=array();
			foreach ($_FILES['gallery']['name'] as $key => $value) {
				$pc=$_FILES['gallery']['name'][$key];
				move_uploaded_file($_FILES['gallery']['tmp_name'][$key], "my-assets/imgs/$pc");
				array_push($gallery,$pc);
			}
		$g=implode(",", $gallery);

		$data=array(
					'name'=>$this->input->post('name'),
					'gender'=>$this->input->post('gender'),
					'hobby'=>implode(",", $h),
					'education'=>$this->input->post('education'),
					'image'=>$img,
					'gallery'=>$g );
		/*echo "<pre>";
		print_r($data);
		exit;*/
		$CI->load->model('Form_model');
		if($CI->Form_model->insert_data($data)){
		$data['data']=$CI->Form_model->show_data();
		/*echo "<pre>";
		print_r($data);
		exit;*/	
		$content = $CI->parser->parse('page/list_form',$data ,true);
		$this->template->full_html_view($content);
		}
	}

	public function delete($id){
		$CI =& get_instance();
		$CI->load->model('Form_model');
		if($CI->Form_model->delete_data($id)){
			$data['data']=$CI->Form_model->show_data();
			$content = $CI->parser->parse('page/list_form',$data ,true);
			$this->template->full_html_view($content);
		}
		else
			{
				echo "Error..!";
			}
	}

	public function edit($id){
		$CI =& get_instance();
		$CI->load->model('Form_model');
		$data['data']=$CI->Form_model->edit_data($id);
		/*echo "<pre>";
		print_r($data);
		exit;*/
		$content = $CI->parser->parse('page/update',$data ,true);
		$this->template->full_html_view($content);
		}

	public function update(){
		$CI =& get_instance();
		$id=$this->input->post('uid');
		$h=$this->input->post('hobby');
		$img=$_FILES['img']['name'];
		move_uploaded_file($_FILES['img']['tmp_name'], "my-asset/img/$img");
		$gallery=array();
			foreach ($_FILES['gallery']['name'] as $key => $value) {
				$pc=$_FILES['gallery']['name'][$key];
				move_uploaded_file($_FILES['gallery']['tmp_name'][$key], "my-assets/img/$pc");
				array_push($gallery,$pc);
			}
		$g=implode(",", $gallery);

		$data=array(
					'name'=>$this->input->post('name'),
					'gender'=>$this->input->post('gender'),
					'hobby'=>implode(",", $h),
					'education'=>$this->input->post('education'),
					'image'=>$img,
					'gallery'=>$g );
		/*echo "<pre>";
		print_r($data);
		exit;*/
		$CI->load->model('Form_model');
		if($CI->Form_model->update_data($id,$data)){
			$data['data']=$this->Form_model->show_data();
			$content = $CI->parser->parse('page/list_form',$data ,true);
			$this->template->full_html_view($content);
		}

	}    


}