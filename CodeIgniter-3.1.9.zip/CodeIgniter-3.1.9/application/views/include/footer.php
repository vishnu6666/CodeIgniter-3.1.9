<footer>
	<div >This is footer</div>
</footer>