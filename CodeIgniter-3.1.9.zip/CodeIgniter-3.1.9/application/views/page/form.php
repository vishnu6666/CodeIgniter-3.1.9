
  <div>
  	<p>welcome to codeigniter with form</p>
  </div>

<div class="container">
  	<form class="form-horizontal" action="<?php echo base_url();?>Cform/insert" method="POST" enctype="multipart/form-data">
    <div class="form-group">
      <label class="control-label col-sm-2" for="name">Name:</label>
      <div class="col-sm-5">
        <input type="text" class="form-control" id="name" placeholder="Enter name" name="name">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="gender">Gender:</label>
      <div class="col-sm-10">          
        <input type="radio" name="gender"  value="male">male
		<input type="radio" name="gender" value="female">female				
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Hobby:</label>
      <div class="col-sm-10">
        <input type="checkbox" name="hobby[]" value="fb">fb
		<input type="checkbox" name="hobby[]" value="wb">wb
		<input type="checkbox" name="hobby[]" value="bb">bb
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Education:</label>
      <div class="col-sm-10">
       <select name="education">
					<option>Be</option>
					<option>Me</option>
					<option>Mtech</option>
		</select>
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Image:</label>
      <div class="col-sm-10">
       <td><input type="file" name="img" >
      </div>
    </div>
     <div class="form-group">
      <label class="control-label col-sm-2" for="name">Gallery:</label>
      <div class="col-sm-10">
        <td><input type="file" name="gallery[]" multiple="">
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
       <input type="submit" name="submit" >
      </div>
    </div>
  </form>
</div>
 		

