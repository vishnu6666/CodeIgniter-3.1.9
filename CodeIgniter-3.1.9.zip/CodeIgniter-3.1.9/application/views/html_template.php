<!DOCTYPE html>
<html>
<head>
	<title>welcome to codeigniter </title>
	<link href="<?php echo base_url()?>assets/css/custom.css" rel="stylesheet" type="text/css"/>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    
	
</head>
<body>
	<div class="wrapper">
            <?php 
                
                $this->load->view('include/header');
            ?>
                {content}
            <?php
           
                $this->load->view('include/footer');
            ?>
        </div>

    <script src="<?php echo base_url()?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</body>
</html>